library(shiny)
library(shinythemes)  # For a nicer theme
library(shinyjs)      # For custom interactivity

# Define UI for application
ui <- fluidPage(
  theme = shinytheme("flatly"),  # Use a modern theme like 'flatly'
  
  # Add some JavaScript to enhance the interactivity
  useShinyjs(),
  
  # Title of the app
  titlePanel("Earthquake Data Insights"),
  
  # Sidebar layout for tabs and content
  navbarPage("Explore Data",
             
             # Earthquake Metadata Tab
             tabPanel("Earthquake Metadata", 
                      value = "earthquake_metadata",
                      uiOutput("earthquake_metadata"),
                      tags$head(tags$style(HTML("
        .nav-tabs { background-color: #2C3E50; }
        .nav-tabs > li > a { color: #ECF0F1; font-size: 16px; }
        .nav-tabs > li > a:hover { background-color: #2980B9; }
      ")))
             ),
             
             # Geographical Data Tab
             tabPanel("Geographical Data", 
                      value = "geographical_data",
                      uiOutput("geographical_data")
             ),
             
             # Additional Metrics Tab
             tabPanel("Additional Metrics", 
                      value = "additional_metrics",
                      uiOutput("additional_metrics")
             ),
             
             # Geospatial Risk & Predictions Tab
             tabPanel("Geospatial Risk & Predictions", 
                      value = "risk_predictions",
                      uiOutput("risk_predictions")
             ),
             
             # Impact Metrics Tab
             tabPanel("Impact Metrics", 
                      value = "impact_metrics",
                      uiOutput("impact_metrics")
             )
  ),
  
  # Add some footer information
  footerPanel(
    p("Developed with love using R and Shiny")
  )
)

# Define server logic
server <- function(input, output, session) {
  
  observe({
    # Earthquake Metadata Tab
    if (input$tabs == "Earthquake Metadata") {
      output$earthquake_metadata <- renderUI({
        source("C:\\Users\\jhaad\\OneDrive\\Documents\\myLeafletApp\\Pages\\Earthquake Metadata.R", local = TRUE)
      })
    }
    
    # Geographical Data Tab
    if (input$tabs == "Geographical Data") {
      output$geographical_data <- renderUI({
        source("C:\\Users\\jhaad\\OneDrive\\Documents\\myLeafletApp\\Pages\\Geographical Data.R", local = TRUE)
      })
    }
    
    # Additional Metrics Tab
    if (input$tabs == "Additional Metrics") {
      output$additional_metrics <- renderUI({
        source("C:\\Users\\jhaad\\OneDrive\\Documents\\myLeafletApp\\Pages\\Additional Metrics.R", local = TRUE)
      })
    }
    
    # Geospatial Risk & Predictions Tab
    if (input$tabs == "Geospatial Risk & Predictions") {
      output$risk_predictions <- renderUI({
        source("C:\\Users\\jhaad\\OneDrive\\Documents\\myLeafletApp\\Pages\\Geospatial Risk and Predictions.R", local = TRUE)
      })
    }
    
    # Impact Metrics Tab
    if (input$tabs == "Impact Metrics") {
      output$impact_metrics <- renderUI({
        source("C:\\Users\\jhaad\\OneDrive\\Documents\\myLeafletApp\\Pages\\Impact Metrics.R", local = TRUE)
      })
    }
  })
}

# Run the application 
shinyApp(ui = ui, server = server)
