library(shiny)
library(leaflet)
library(plotly)
library(dplyr)
library(sf)

# Load Earthquake Data
eq_data <- read.csv("C:\\Users\\jhaad\\OneDrive\\Documents\\myLeafletApp\\mydata\\refined_combined_earthquake_data.csv", stringsAsFactors = FALSE)

# Preprocess Data
eq_data_cleaned <- eq_data %>%
  filter(!is.na(magnitude) & !is.na(latitude) & !is.na(longitude)) %>%
  mutate(
    alert = factor(alert, levels = c("green", "yellow", "orange", "red")),
    date_time = as.POSIXct(date_time, format = "%Y-%m-%d %H:%M:%S")
  )

# Define UI
ui <- fluidPage(
  titlePanel("Geospatial Risk and Prediction - Earthquake Data Analysis"),
  
  sidebarLayout(
    sidebarPanel(
      h3("Explore Earthquake Risk and Predictions")
    ),
    
    mainPanel(
      tabsetPanel(
        
        # Map Tab
        tabPanel("Earthquake Map", 
                 leafletOutput("map_earthquakes"), 
                 p("This interactive map visualizes earthquake data. Each circle represents an earthquake, with size proportional to its magnitude. The color of the circle indicates the alert level.")),
        
        # Magnitude vs CDI Scatter Plot Tab
        tabPanel("Magnitude vs CDI", 
                 plotlyOutput("plot_mag_vs_cdi"), 
                 p("This scatter plot shows the relationship between earthquake magnitude and the CDI (Shake Intensity). The color indicates the alert level.")),
        
        # MMI Heatmap Tab
        tabPanel("MMI Heatmap", 
                 plotlyOutput("plot_mmi_heatmap"), 
                 p("This heatmap visualizes the relationship between earthquake magnitude, depth, and MMI (Modified Mercalli Intensity).")),
        
        # Predicted vs Actual CDI Tab
        tabPanel("Predicted vs Actual CDI", 
                 plotlyOutput("plot_model_performance"), 
                 p("This scatter plot shows the comparison between the predicted and actual CDI values based on a regression model.")),
        
        # Gap vs Magnitude Scatter Plot Tab
        tabPanel("Gap vs Magnitude", 
                 plotlyOutput("plot_gap_vs_mag"), 
                 p("This scatter plot shows the relationship between the earthquake's gap and its magnitude, which reflects station coverage.")),
        
        # Station Coverage by Alert Level Tab
        tabPanel("Station Coverage", 
                 plotlyOutput("plot_coverage_bar"), 
                 p("This bar chart displays the number of stations categorized by alert levels. It shows how the station count varies across different alert levels."))
      )
    )
  )
)

# Define Server Logic
server <- function(input, output) {
  
  # Map for Earthquake Data
  output$map_earthquakes <- renderLeaflet({
    leaflet(eq_data_cleaned) %>%
      addTiles() %>%
      addCircles(
        lng = ~longitude,
        lat = ~latitude,
        weight = 1,
        radius = ~magnitude * 10000,  # Scale size by magnitude
        color = ~colorFactor(c("blue", "orange", "red"), domain = c("Low", "Medium", "High"))(alert),
        popup = ~paste("Magnitude:", magnitude, "<br>", "Depth:", depth, "<br>", "Alert:", alert)
      ) %>%
      addLegend(
        position = "bottomright", 
        pal = colorFactor(c("blue", "orange", "red"), domain = c("Low", "Medium", "High")), 
        values = ~alert,
        title = "Alert Level"
      )
  })
  
  # Magnitude vs CDI Scatter Plot
  output$plot_mag_vs_cdi <- renderPlotly({
    plot_ly(
      data = eq_data_cleaned,
      x = ~magnitude,
      y = ~cdi,
      type = "scatter",
      mode = "markers",
      marker = list(color = ~alert, colorscale = "Viridis"),
      text = ~paste("Magnitude:", magnitude, "<br>", "CDI:", cdi)
    ) %>%
      layout(
        title = "Magnitude vs CDI",
        xaxis = list(title = "Magnitude"),
        yaxis = list(title = "CDI")
      )
  })
  
  # MMI Heatmap
  output$plot_mmi_heatmap <- renderPlotly({
    plot_ly(
      data = eq_data_cleaned,
      x = ~magnitude,
      y = ~depth,
      z = ~mmi,
      type = "heatmap",
      colorscale = "Jet"
    ) %>%
      layout(
        title = "MMI Heatmap by Magnitude and Depth",
        xaxis = list(title = "Magnitude"),
        yaxis = list(title = "Depth (km)")
      )
  })
  
  # Predicted vs Actual CDI Plot
  output$plot_model_performance <- renderPlotly({
    model <- lm(cdi ~ magnitude + depth + gap + alert, data = eq_data_cleaned)
    eq_data_cleaned$predicted_cdi <- predict(model, eq_data_cleaned)
    
    plot_ly(
      data = eq_data_cleaned,
      x = ~cdi,
      y = ~predicted_cdi,
      type = "scatter",
      mode = "markers",
      marker = list(color = "blue"),
      text = ~paste("Actual CDI:", cdi, "<br>", "Predicted CDI:", predicted_cdi)
    ) %>%
      layout(
        title = "Predicted vs Actual CDI",
        xaxis = list(title = "Actual CDI"),
        yaxis = list(title = "Predicted CDI")
      )
  })
  
  # Gap vs Magnitude Scatter Plot
  output$plot_gap_vs_mag <- renderPlotly({
    plot_ly(
      data = eq_data_cleaned,
      x = ~magnitude,
      y = ~gap,
      type = "scatter",
      mode = "markers",
      marker = list(color = ~alert, colorscale = "Viridis"),
      text = ~paste("Magnitude:", magnitude, "<br>", "Gap:", gap)
    ) %>%
      layout(
        title = "Gap vs Magnitude (Station Coverage)",
        xaxis = list(title = "Magnitude"),
        yaxis = list(title = "Gap (°)")
      )
  })
  
  # Station Coverage by Alert Level Bar Chart
  output$plot_coverage_bar <- renderPlotly({
    coverage_data <- eq_data_cleaned %>%
      group_by(alert) %>%
      summarize(station_count = n())
    
    plot_ly(
      data = coverage_data,
      x = ~alert,
      y = ~station_count,
      type = "bar",
      marker = list(color = "steelblue")
    ) %>%
      layout(
        title = "Station Coverage by Alert Level",
        xaxis = list(title = "Alert Level"),
        yaxis = list(title = "Number of Stations")
      )
  })
}

# Run the Shiny app
shinyApp(ui = ui, server = server)
