library(shiny)
library(leaflet)
library(plotly)
library(dplyr)
library(lubridate)
library(geojsonio)

# Define UI
ui <- fluidPage(
  titlePanel("Earthquake Metadata"),
  
  sidebarLayout(
    sidebarPanel(
      h3("Earthquake Data Visualizations"),
      p("Explore the interactive visualizations related to earthquake data."),
      hr(),
      h4("About the Data"),
      p("This application visualizes earthquake events, their locations, magnitudes, and intensity levels, with details for each continent and country.")
    ),
    
    mainPanel(
      # Plot 1: Earthquake Count by Continent
      plotlyOutput("plot_continent"),
      p("This bar plot shows the number of earthquake events by continent."),
      
      # Plot 2: Earthquake Count by Country (North America)
      plotlyOutput("plot_country"),
      p("This bar plot displays earthquake counts in North America, with countries on the x-axis."),
      
      # Plot 3: Earthquake Locations Map with Details
      plotlyOutput("plot_location"),
      p("This interactive map shows earthquake locations with additional details on magnitude, depth, and location."),
      
      # Plot 4: Magnitude Distribution by Continent
      plotlyOutput("plot_boxplot"),
      p("This boxplot displays the distribution of earthquake magnitudes across different continents."),
      
      # Plot 5: CDI vs MMI Scatter Plot
      plotlyOutput("plot_cdi_mmi"),
      p("This scatter plot visualizes the relationship between the Community Determined Intensity (CDI) and Modified Mercalli Intensity (MMI) for earthquake events."),
      
      # Plot 6: Leaflet Map with Alert Levels
      leafletOutput("leaflet_map"),
      p("This map displays earthquake events with alert levels and includes an overlay of seismic fault lines if available.")
    )
  )
)

# Define Server logic
server <- function(input, output) {
  
  # Load and preprocess earthquake data
  eq_data <- read.csv("C:/Users/jhaad/OneDrive/Documents/myLeafletApp/mydata/refined_combined_earthquake_data.csv", stringsAsFactors = FALSE)
  eq_data <- eq_data %>%
    filter(alert != "") %>%
    mutate(
      date_time = ymd_hms(date_time),
      alert = factor(alert, levels = c("green", "yellow", "orange", "red")),
      continent = as.factor(continent)
    )
  
  # Clean data for visualization
  eq_data_cleaned <- eq_data %>%
    filter(!is.na(latitude) & !is.na(longitude) & !is.na(magnitude))
  
  # 1. Earthquake Count by Continent
  continent_data <- eq_data_cleaned %>%
    group_by(continent) %>%
    summarize(count = n())
  
  output$plot_continent <- renderPlotly({
    plot_ly(
      data = continent_data,
      x = ~continent,
      y = ~count,
      type = "bar",
      marker = list(color = "steelblue")
    ) %>%
      layout(
        title = "Earthquake Count by Continent",
        xaxis = list(title = "Continent"),
        yaxis = list(title = "Number of Earthquakes"),
        clickmode = "event+select"
      )
  })
  
  # 2. Earthquake Count by Country (North America)
  country_data <- eq_data_cleaned %>%
    filter(continent == "North America") %>%
    group_by(country) %>%
    summarize(count = n()) %>%
    arrange(desc(count))
  
  output$plot_country <- renderPlotly({
    plot_ly(
      data = country_data,
      x = ~reorder(country, -count),
      y = ~count,
      type = "bar",
      marker = list(color = "orange")
    ) %>%
      layout(
        title = "Earthquake Count by Country (North America)",
        xaxis = list(title = "Country"),
        yaxis = list(title = "Number of Earthquakes"),
        clickmode = "event+select"
      )
  })
  
  # 3. Earthquake Locations Map with Details
  output$plot_location <- renderPlotly({
    plot_ly(
      data = eq_data_cleaned,
      lat = ~latitude,
      lon = ~longitude,
      type = "scattermapbox",
      mode = "markers",
      marker = list(size = ~magnitude * 2, color = ~magnitude, colorscale = "Viridis"),
      text = ~paste(
        "Location:", location, "<br>",
        "Country:", country, "<br>",
        "Magnitude:", magnitude, "<br>",
        "Depth:", depth, "km"
      )
    ) %>%
      layout(
        mapbox = list(style = "carto-darkmatter", zoom = 1),
        title = "Earthquake Locations"
      )
  })
  
  # 4. Magnitude Distribution by Continent
  output$plot_boxplot <- renderPlotly({
    plot_ly(
      data = eq_data_cleaned,
      x = ~continent,
      y = ~magnitude,
      type = "box",
      boxpoints = "all",
      jitter = 0.5,
      pointpos = -1.8,
      marker = list(color = "red")
    ) %>%
      layout(
        title = "Magnitude Distribution by Continent",
        xaxis = list(title = "Continent"),
        yaxis = list(title = "Magnitude")
      )
  })
  
  # 5. CDI vs MMI Scatter Plot
  output$plot_cdi_mmi <- renderPlotly({
    plot_ly(
      data = eq_data_cleaned,
      x = ~mmi,
      y = ~cdi,
      type = "scatter",
      mode = "markers",
      marker = list(size = ~magnitude, color = ~alert, colorscale = "Rainbow"),
      text = ~paste(
        "Title:", title, "<br>",
        "Magnitude:", magnitude, "<br>",
        "Depth:", depth, "km", "<br>",
        "CDI:", cdi, "<br>",
        "MMI:", mmi
      )
    ) %>%
      layout(
        title = "Interactive CDI vs MMI Scatter Plot",
        xaxis = list(title = "Modified Mercalli Intensity (MMI)"),
        yaxis = list(title = "Community Determined Intensity (CDI)"),
        showlegend = TRUE
      )
  })
  
  # 6. Leaflet Map with Alert Levels
  output$leaflet_map <- renderLeaflet({
    geojson_path <- "path_to_fault_lines.geojson"
    if (file.exists(geojson_path)) {
      fault_lines <- geojson_read(geojson_path, what = "sp")
      
      leaflet(eq_data_cleaned) %>%
        addProviderTiles(providers$CartoDB.DarkMatter) %>%
        addCircleMarkers(
          ~longitude, ~latitude,
          radius = ~magnitude,
          color = ~alert,
          popup = ~paste(
            "Location:", location, "<br>",
            "Country:", country, "<br>",
            "Magnitude:", magnitude
          )
        ) %>%
        addGeoJSON(fault_lines, color = "red", weight = 2) %>%
        addLegend(
          position = "bottomright",
          colors = c("green", "yellow", "orange", "red"),
          labels = c("Green", "Yellow", "Orange", "Red"),
          title = "Alert Levels"
        )
    } else {
      leaflet(eq_data_cleaned) %>%
        addProviderTiles(providers$CartoDB.DarkMatter) %>%
        addCircleMarkers(
          ~longitude, ~latitude,
          radius = ~magnitude,
          color = ~alert,
          popup = ~paste(
            "Location:", location, "<br>",
            "Country:", country, "<br>",
            "Magnitude:", magnitude
          )
        ) %>%
        addLegend(
          position = "bottomright",
          colors = c("green", "yellow", "orange", "red"),
          labels = c("Green", "Yellow", "Orange", "Red"),
          title = "Alert Levels"
        )
    }
  })
}

# Run the application 
shinyApp(ui = ui, server = server)
