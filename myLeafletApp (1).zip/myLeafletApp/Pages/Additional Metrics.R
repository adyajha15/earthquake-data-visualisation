library(shiny)
library(plotly)
library(dplyr)
library(leaflet)

# Load Earthquake Data
eq_data <- read.csv("C:\\Users\\jhaad\\OneDrive\\Documents\\myLeafletApp\\mydata\\refined_combined_earthquake_data.csv", stringsAsFactors = FALSE)

# Preprocess Data
eq_data_cleaned <- eq_data %>%
  filter(!is.na(magnitude) & !is.na(latitude) & !is.na(longitude)) %>%
  mutate(
    alert = factor(alert, levels = c("green", "yellow", "orange", "red")),
    date_time = as.POSIXct(date_time, format = "%Y-%m-%d %H:%M:%S")
  )

# 1. Significance Score (Sig) vs Magnitude
plot_sig_vs_mag <- plot_ly(
  data = eq_data_cleaned,
  x = ~magnitude,
  y = ~sig,
  type = "scatter",
  mode = "markers",
  marker = list(size = ~magnitude * 2, color = ~alert, colorscale = "Rainbow"),
  text = ~paste(
    "Magnitude Type:", magtype, "<br>",
    "Significance Score (Sig):", sig, "<br>",
    "Gap:", gap, "°<br>",
    "Dmin:", dmin, "km"
  )
) %>%
  layout(
    title = "Significance Score vs. Magnitude",
    xaxis = list(title = "Magnitude"),
    yaxis = list(title = "Significance Score (Sig)"),
    showlegend = TRUE
  )

# 2. Distance to Nearest Station (Dmin) vs Depth
plot_dmin_vs_depth <- plot_ly(
  data = eq_data_cleaned,
  x = ~dmin,
  y = ~depth,
  type = "scatter",
  mode = "markers",
  marker = list(size = ~magnitude, color = ~alert, colorscale = "Viridis"),
  text = ~paste(
    "Distance to Nearest Station (Dmin):", dmin, "km<br>",
    "Depth:", depth, "km<br>",
    "Magnitude:", magnitude, "<br>",
    "Alert Level:", alert
  )
) %>%
  layout(
    title = "Distance to Nearest Station vs. Depth",
    xaxis = list(title = "Distance to Nearest Station (km)"),
    yaxis = list(title = "Depth (km)"),
    showlegend = TRUE
  )

# 3. Gap Distribution (Station Coverage)
plot_gap_distribution <- plot_ly(
  data = eq_data_cleaned,
  x = ~gap,
  type = "histogram",
  marker = list(color = "orange"),
  text = ~paste(
    "Gap:", gap, "°<br>",
    "Magnitude:", magnitude, "<br>",
    "Significance (Sig):", sig
  )
) %>%
  layout(
    title = "Gap Distribution (Station Coverage)",
    xaxis = list(title = "Gap (°)"),
    yaxis = list(title = "Frequency"),
    showlegend = FALSE
  )

# 4. Magnitude Type Frequency
magtype_data <- eq_data_cleaned %>%
  group_by(magtype) %>%
  summarize(count = n()) %>%
  arrange(desc(count))

plot_magtype <- plot_ly(
  data = magtype_data,
  x = ~reorder(magtype, -count),
  y = ~count,
  type = "bar",
  marker = list(color = "steelblue"),
  text = ~paste("Magnitude Type:", magtype, "<br>", "Count:", count)
) %>%
  layout(
    title = "Frequency of Magnitude Types",
    xaxis = list(title = "Magnitude Type"),
    yaxis = list(title = "Frequency"),
    showlegend = FALSE
  )

plot_gap_vs_mag <- plot_ly(
  data = eq_data_cleaned,
  x = ~magnitude,
  y = ~gap,
  type = "scatter",
  mode = "markers",
  marker = list(color = ~alert, colorscale = "Viridis"),
  text = ~paste(
    "Gap:", gap, "°<br>",
    "Magnitude:", magnitude, "<br>",
    "Significance:", sig
  )
) %>%
  layout(
    title = "Magnitude vs. Gap (Station Coverage)",
    xaxis = list(title = "Magnitude"),
    yaxis = list(title = "Gap (°)"),
    showlegend = FALSE
  )

# 5. Combined 3D Visualization
plot_3d_combined <- plot_ly(
  data = eq_data_cleaned,
  x = ~magnitude,
  y = ~dmin,
  z = ~sig,
  type = "scatter3d",
  mode = "markers",
  marker = list(size = ~magnitude, color = ~alert, colorscale = "Jet"),
  text = ~paste(
    "Magnitude:", magnitude, "<br>",
    "Distance to Nearest Station (Dmin):", dmin, "km<br>",
    "Significance Score (Sig):", sig, "<br>",
    "Alert Level:", alert
  )
) %>%
  layout(
    title = "3D Visualization: Magnitude vs. Dmin vs. Sig",
    scene = list(
      xaxis = list(title = "Magnitude"),
      yaxis = list(title = "Distance to Nearest Station (Dmin)"),
      zaxis = list(title = "Significance Score (Sig)")
    )
  )

# Define UI
ui <- fluidPage(
  titlePanel("Earthquake Data Analysis"),
  
  # Sidebar for navigation
  sidebarLayout(
    sidebarPanel(
      h3("Exploring Earthquake Metrics")
    ),
    
    mainPanel(
      tabsetPanel(
        tabPanel("Significance vs Magnitude", 
                 plotlyOutput("plot_sig_vs_mag"), 
                 p("This plot shows the relationship between the significance score (Sig) and the earthquake magnitude. Larger magnitudes tend to have higher significance scores.")),
        
        tabPanel("Dmin vs Depth", 
                 plotlyOutput("plot_dmin_vs_depth"),
                 p("This plot illustrates the relationship between the distance to the nearest station (Dmin) and the depth of earthquakes. A shorter distance to a station often correlates with more accurate data.")),
        
        tabPanel("Gap Distribution", 
                 plotlyOutput("plot_gap_distribution"),
                 p("This histogram shows the distribution of gap values, which indicate the station coverage for each earthquake. A larger gap means less coverage.")),
        
        tabPanel("Magnitude Type Frequency", 
                 plotlyOutput("plot_magtype"),
                 p("This bar chart shows the frequency of each magnitude type in the dataset. It highlights the most common magnitude types recorded.")),
        
        tabPanel("Magnitude vs Gap", 
                 plotlyOutput("plot_gap_vs_mag"),
                 p("This scatter plot visualizes the relationship between magnitude and gap, highlighting how station coverage changes with magnitude.")),
        
        tabPanel("3D Visualization", 
                 plotlyOutput("plot_3d_combined"),
                 p("This 3D plot combines magnitude, distance to the nearest station (Dmin), and significance score (Sig) to provide an in-depth view of earthquake data."))
      )
    )
  )
)

# Define Server Logic
server <- function(input, output) {
  
  # Render plots in corresponding tabs
  output$plot_sig_vs_mag <- renderPlotly({ plot_sig_vs_mag })
  output$plot_dmin_vs_depth <- renderPlotly({ plot_dmin_vs_depth })
  output$plot_gap_distribution <- renderPlotly({ plot_gap_distribution })
  output$plot_magtype <- renderPlotly({ plot_magtype })
  output$plot_gap_vs_mag <- renderPlotly({ plot_gap_vs_mag })
  output$plot_3d_combined <- renderPlotly({ plot_3d_combined })
}

# Run the app
shinyApp(ui = ui, server = server)
