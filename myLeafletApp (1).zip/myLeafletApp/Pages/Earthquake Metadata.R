library(shiny)
library(leaflet)
library(dplyr)
library(lubridate)

# Define UI
ui <- fluidPage(
  # App title
  titlePanel("Earthquake Metadata"),
  
  # Sidebar layout
  sidebarLayout(
    sidebarPanel(
      h3("Earthquake Data"),
      p("This application displays earthquake data on a map with relevant metadata."),
      
      # About Section
      hr(),
      h4("About the Data"),
      p("This application visualizes earthquake events using data collected from various sources. Each earthquake is represented by a marker on the map, which includes details such as the magnitude, depth, location, continent, country, and the exact date and time of the event."),
      p("You can interact with the map by zooming in and out. Markers are clustered to improve performance, and popups display the metadata for each event.")
    ),
    
    # Main panel to display the map
    mainPanel(
      leafletOutput("earthquake_map")
    )
  )
)

# Define server logic
server <- function(input, output) {
  
  # Load and preprocess earthquake data
  eq_data <- read.csv("C:/Users/jhaad/OneDrive/Documents/myLeafletApp/mydata/refined_combined_earthquake_data.csv", stringsAsFactors = FALSE)
  
  # Handle missing or invalid date_time entries by safely parsing them
  eq_data$date_time <- tryCatch(
    ymd_hms(eq_data$date_time),
    error = function(e) as.POSIXct(NA)  # Handle errors by assigning NA
  )
  
  # Clean data: filter rows where necessary columns are not NA
  eq_data_cleaned <- eq_data %>%
    filter(!is.na(magnitude) & !is.na(latitude) & !is.na(longitude) & !is.na(date_time))
  
  # Further processing in case there are any other parsing errors
  eq_data_cleaned$date_time <- tryCatch(
    ymd_hms(eq_data_cleaned$date_time),
    error = function(e) as.POSIXct(NA)  # Handle errors by assigning NA
  )
  
  # Ensure row counts match
  if (nrow(eq_data_cleaned) != nrow(eq_data)) {
    warning("There are mismatched rows due to missing or invalid data in date_time.")
  }
  
  # Render the leaflet map with custom UI
  output$earthquake_map <- renderLeaflet({
    leaflet(eq_data_cleaned) %>%
      addProviderTiles(providers$CartoDB.DarkMatter) %>%
      addMarkers(
        ~longitude, ~latitude,
        popup = ~paste(
          "<strong>Title:</strong>", title, "<br>",
          "<strong>Magnitude:</strong>", magnitude, "<br>",
          "<strong>Depth:</strong>", depth, "km<br>",
          "<strong>Location:</strong>", location, "<br>",
          "<strong>Continent:</strong>", continent, "<br>",
          "<strong>Country:</strong>", country, "<br>",
          "<strong>Date/Time:</strong>", date_time, "<br>"
        ),
        clusterOptions = markerClusterOptions(
          maxClusterRadius = 30, 
          spiderfyOnMaxZoom = TRUE, 
          disableClusteringAtZoom = 5
        )
      ) %>%
      addLegend(
        position = "bottomright",
        colors = c("blue"),
        labels = c("Earthquake Events"),
        title = "Earthquake Data"
      )
  })
}

# Run the application 
shinyApp(ui = ui, server = server)
