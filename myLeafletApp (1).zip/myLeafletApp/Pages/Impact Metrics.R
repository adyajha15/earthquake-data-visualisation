# Install and load necessary libraries

library(shiny)
library(ggplot2)
library(dplyr)
library(lubridate)
library(plotly)
library(leaflet)
library(leaflet.extras)
library(corrplot)

# Load dataset
eq_data <- read.csv("C:\\Users\\jhaad\\OneDrive\\Documents\\myLeafletApp\\mydata\\refined_combined_earthquake_data.csv", stringsAsFactors = FALSE)
eq_data$date_time <- ymd_hms(eq_data$date_time)

# Clean data
eq_data_cleaned <- eq_data %>%
  filter(!is.na(magnitude) & !is.na(latitude) & !is.na(longitude) & 
           !is.na(cdi) & !is.na(mmi) & !is.na(alert) & !is.na(tsunami)) %>%
  filter(alert != "")

# UI layout
ui <- fluidPage(
  titlePanel("Earthquake Data Visualizations"),
  
  sidebarLayout(
    sidebarPanel(
      h3("Insights & Graphs"),
      p("This interactive dashboard showcases various plots and insights from earthquake data."),
      p("You can explore different visualizations that show relationships between magnitude, depth, intensity, tsunami risk, and alert levels.")
    ),
    
    mainPanel(
      tabsetPanel(
        tabPanel("MMI by Location",
                 plotOutput("mmi_location"),
                 p("This bar plot shows the distribution of Modified Mercalli Intensity (MMI) by continent.")
        ),
        tabPanel("Tsunami Indicator vs Alert Level",
                 plotOutput("tsunami_alert"),
                 p("This bar plot represents the relationship between tsunami occurrence (Yes/No) and alert levels.")
        ),
        tabPanel("MMI by Alert Level",
                 plotOutput("mmi_alert"),
                 p("This plot shows the relationship between Modified Mercalli Intensity (MMI) and the alert level.")
        ),
        tabPanel("Interactive CDI vs Magnitude",
                 plotlyOutput("cdi_magnitude"),
                 p("This scatter plot lets you explore the relationship between CDI (Community Determined Intensity) and earthquake magnitude, with colors indicating alert levels.")
        ),
        tabPanel("Interactive Map",
                 leafletOutput("earthquake_map"),
                 p("An interactive map visualizes earthquake locations, magnitudes, and alert levels.")
        ),
        tabPanel("Heatmap",
                 leafletOutput("heatmap"),
                 p("A heatmap showing the concentration of earthquakes and their intensity.")
        ),
        tabPanel("MMI vs CDI by Alert Level",
                 plotOutput("mmi_cdi"),
                 p("This scatter plot shows the relationship between MMI and CDI, faceted by alert levels.")
        ),
        tabPanel("Correlation Plot",
                 plotOutput("correlation"),
                 p("A correlation plot showing relationships between magnitude, CDI, and depth.")
        ),
        tabPanel("3D Plot of Magnitude, Depth, and CDI",
                 plotlyOutput("3d_plot"),
                 p("A 3D scatter plot showing magnitude, depth, and CDI of earthquakes.")
        ),
        tabPanel("Alert Levels Over Time",
                 plotOutput("alert_time"),
                 p("A time series plot that tracks alert levels over time, showing how they change based on earthquake events.")
        )
      )
    )
  )
)

# Server logic
server <- function(input, output) {
  
  # Plot 1: MMI Distribution by Location
  output$mmi_location <- renderPlot({
    ggplot(eq_data_cleaned, aes(x = mmi, fill = continent)) +
      geom_bar() +
      labs(title = "Modified Mercalli Intensity (MMI) by Location",
           x = "Modified Mercalli Intensity (MMI)",
           y = "Count",
           fill = "Continent") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1))
  })
  
  # Plot 2: Tsunami Indicator vs Alert Level
  output$tsunami_alert <- renderPlot({
    ggplot(eq_data_cleaned, aes(x = factor(tsunami), fill = factor(alert))) + 
      geom_bar() + 
      scale_fill_manual(values = c("green", "yellow", "orange", "red")) + 
      labs(title = "Tsunami Indicator (Binary) Colored by Alert Level",
           x = "Tsunami Indicator (1 = Yes, 0 = No)",
           y = "Count",
           fill = "Alert Level") +
      theme_minimal()
  })
  
  # Plot 3: MMI by Alert Level
  output$mmi_alert <- renderPlot({
    ggplot(eq_data_cleaned, aes(x = factor(mmi), fill = factor(alert))) +
      geom_bar() +
      scale_fill_manual(values = c("green", "yellow", "orange", "red")) +
      labs(title = "Modified Mercalli Intensity (MMI) by Alert Level",
           x = "Modified Mercalli Intensity (MMI)",
           y = "Count",
           fill = "Alert Level") +
      theme_minimal()
  })
  
  # Interactive Plot for CDI vs Magnitude
  output$cdi_magnitude <- renderPlotly({
    plot_ly(eq_data_cleaned, 
            x = ~magnitude, 
            y = ~cdi, 
            type = 'scatter', 
            mode = 'markers', 
            marker = list(color = ~alert, colorscale = c('green', 'yellow', 'orange', 'red')),
            text = ~paste("Title: ", title, "<br>Depth: ", depth, " km"),
            hoverinfo = 'text') %>%
      layout(
        title = "Interactive CDI vs Magnitude",
        xaxis = list(title = "Magnitude"),
        yaxis = list(title = "Community Determined Intensity (CDI)"),
        showlegend = FALSE
      )
  })
  
  # Interactive Map with Leaflet
  output$earthquake_map <- renderLeaflet({
    leaflet(eq_data_cleaned) %>%
      addTiles() %>%
      addCircleMarkers(lng = ~longitude, lat = ~latitude, 
                       color = ~case_when(
                         alert == "green" ~ "green",
                         alert == "yellow" ~ "yellow",
                         alert == "orange" ~ "orange",
                         alert == "red" ~ "red",
                         TRUE ~ "gray"
                       ),
                       radius = ~log(magnitude)*2, # Adjust size based on magnitude
                       popup = ~paste(
                         "<strong>Title:</strong>", title, "<br>",
                         "<strong>Magnitude:</strong>", magnitude, "<br>",
                         "<strong>CDI:</strong>", cdi, "<br>",
                         "<strong>Depth:</strong>", depth, " km<br>",
                         "<strong>Location:</strong>", location, "<br>",
                         "<strong>Alert Level:</strong>", alert, "<br>",
                         "<strong>Tsunami:</strong>", ifelse(tsunami == 1, "Yes", "No")
                       )) %>%
      addLegend(position = "bottomright",
                colors = c("green", "yellow", "orange", "red"),
                labels = c("Green: Low risk", "Yellow: Moderate risk", "Orange: High risk", "Red: Very high risk"),
                title = "Alert Levels")
  })
  
  # Heatmap of Earthquakes
  output$heatmap <- renderLeaflet({
    leaflet(eq_data_cleaned) %>%
      addTiles() %>%
      addHeatmap(lng = ~longitude, lat = ~latitude, 
                 intensity = ~magnitude, 
                 blur = 20, max = 0.05, 
                 radius = 15)
  })
  
  # Plot for MMI vs CDI by Alert Level
  output$mmi_cdi <- renderPlot({
    ggplot(eq_data_cleaned, aes(x = cdi, y = mmi, color = alert)) +
      geom_point(size = 3) +
      facet_wrap(~alert) +
      labs(title = "MMI vs CDI by Alert Level",
           x = "Community Determined Intensity (CDI)",
           y = "Modified Mercalli Intensity (MMI)") +
      scale_color_manual(values = c("green", "yellow", "orange", "red")) +
      theme_minimal()
  })
  
  # Correlation plot for numeric variables
  output$correlation <- renderPlot({
    numeric_columns <- eq_data_cleaned %>%
      select(magnitude, cdi, depth) %>%
      cor()
    
    corrplot(numeric_columns, method = "circle")
  })
  
  # 3D Plot for Magnitude, Depth, and CDI
  output$`3d_plot` <- renderPlotly({
    plot_ly(eq_data_cleaned, 
            x = ~magnitude, 
            y = ~depth, 
            z = ~cdi, 
            type = 'scatter3d', 
            mode = 'markers',
            marker = list(size = 5, color = ~alert, colorscale = c('green', 'yellow', 'orange', 'red')),
            text = ~paste("Title: ", title, "<br>Location: ", location)) %>%
      layout(title = "3D Plot of Magnitude, Depth, and CDI",
             scene = list(xaxis = list(title = "Magnitude"),
                          yaxis = list(title = "Depth (km)"),
                          zaxis = list(title = "Community Determined Intensity (CDI)")))
  })
  
  
  # Time series plot for alert level over time
  output$alert_time <- renderPlot({
    ggplot(eq_data_cleaned, aes(x = date_time, y = alert, color = alert)) +
      geom_jitter(width = 0.2, height = 0.1, alpha = 0.7) +
      scale_color_manual(values = c("green", "yellow", "orange", "red")) +
      labs(title = "Alert Levels Over Time",
           x = "Time",
           y = "Alert Level") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1))
  })
}

# Run the Shiny app
shinyApp(ui = ui, server = server)

